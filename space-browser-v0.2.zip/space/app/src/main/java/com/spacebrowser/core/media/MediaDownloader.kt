package com.spacebrowser.core.media

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import com.yausername.youtubedl_android.mapper.VideoInfo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

/**
 * Optional media downloader backed by yt-dlp (via the youtubedl-android
 * runtime). Entirely opt-in: nothing here runs unless the user enables it in
 * Settings, and it never attempts to bypass DRM-protected streams — protected
 * content simply fails with the extractor's error.
 *
 * Files land in the device's Downloads/SPACE folder.
 */
object MediaDownloader {

    enum class Status { DOWNLOADING, DONE, ERROR }

    data class MediaJob(
        val id: String,
        val title: String,
        val progress: Float,      // 0..100, -1 while indeterminate
        val etaSeconds: Long,
        val status: Status,
        val message: String? = null,
    )

    data class Choice(val label: String, val selector: String)

    /** Simple, dependable format presets instead of a wall of format IDs. */
    val choices = listOf(
        Choice("Best video", "bv*+ba/b"),
        Choice("Video up to 720p (smaller)", "bv*[height<=720]+ba/b[height<=720]/b"),
        Choice("Audio only (m4a)", "ba[ext=m4a]/ba/b"),
    )

    /** Live job list for the UI. */
    val jobs = MutableStateFlow<List<MediaJob>>(emptyList())

    @Volatile private var initialized = false
    private val initGate = Any()

    /** First call extracts the bundled Python runtime; takes a few seconds. */
    suspend fun ensureReady(context: Context): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            synchronized(initGate) {
                if (!initialized) {
                    val app = context.applicationContext
                    YoutubeDL.getInstance().init(app)
                    try {
                        com.yausername.ffmpeg.FFmpeg.getInstance().init(app)
                    } catch (_: Throwable) {
                        // Without ffmpeg, merged formats fall back to single-file ones.
                    }
                    initialized = true
                }
            }
            Result.success(Unit)
        } catch (t: Throwable) {
            Result.failure(t)
        }
    }

    suspend fun fetchInfo(context: Context, url: String): Result<VideoInfo> =
        withContext(Dispatchers.IO) {
            try {
                ensureReady(context).getOrThrow()
                Result.success(YoutubeDL.getInstance().getInfo(YoutubeDLRequest(url)))
            } catch (t: Throwable) {
                Result.failure(t)
            }
        }

    val hasActiveJob: Boolean
        get() = jobs.value.any { it.status == Status.DOWNLOADING }

    /** Starts one download; a second concurrent one is refused for simplicity. */
    fun download(
        scope: CoroutineScope,
        context: Context,
        url: String,
        title: String,
        selector: String,
        onRefused: () -> Unit,
    ) {
        if (hasActiveJob) {
            onRefused()
            return
        }
        val app = context.applicationContext
        val jobId = UUID.randomUUID().toString()
        update(MediaJob(jobId, title.ifBlank { "Media" }, -1f, 0, Status.DOWNLOADING))

        scope.launch(Dispatchers.IO) {
            try {
                ensureReady(app).getOrThrow()
                val outDir = File(app.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "SPACE")
                    .apply { mkdirs() }
                outDir.listFiles()?.forEach { it.delete() } // stale temp files

                val request = YoutubeDLRequest(url).apply {
                    addOption("-f", selector)
                    addOption("-o", File(outDir, "%(title).96s.%(ext)s").absolutePath)
                    addOption("--restrict-filenames")
                    addOption("--no-playlist")
                    addOption("--no-mtime")
                }
                YoutubeDL.getInstance().execute(request, jobId) { progress, eta, _ ->
                    update(jobId) { it.copy(progress = progress, etaSeconds = eta) }
                }

                val produced = outDir.listFiles()?.maxByOrNull { it.lastModified() }
                    ?: throw IllegalStateException("No file was produced")
                val savedName = exportToPublicDownloads(app, produced)
                update(jobId) {
                    it.copy(status = Status.DONE, progress = 100f, message = "Saved to Downloads/SPACE/$savedName")
                }
            } catch (t: Throwable) {
                update(jobId) {
                    it.copy(
                        status = Status.ERROR,
                        message = t.message?.take(300) ?: "Download failed",
                    )
                }
            }
        }
    }

    fun cancel(jobId: String) {
        try {
            YoutubeDL.getInstance().destroyProcessById(jobId)
        } catch (_: Throwable) {
        }
        update(jobId) { it.copy(status = Status.ERROR, message = "Cancelled") }
    }

    fun clearFinished() {
        jobs.value = jobs.value.filter { it.status == Status.DOWNLOADING }
    }

    // Internals -----------------------------------------------------------------

    private fun update(job: MediaJob) {
        jobs.value = listOf(job) + jobs.value.filter { it.id != job.id }
    }

    private fun update(id: String, transform: (MediaJob) -> MediaJob) {
        jobs.value = jobs.value.map { if (it.id == id) transform(it) else it }
    }

    /** Move the finished file into the shared Downloads/SPACE folder. */
    private fun exportToPublicDownloads(context: Context, file: File): String {
        val mime = MimeTypeMap.getSingleton()
            .getMimeTypeFromExtension(file.extension.lowercase()) ?: "application/octet-stream"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, file.name)
                put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/SPACE")
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Couldn't create the download entry")
            resolver.openOutputStream(uri)?.use { out ->
                file.inputStream().use { it.copyTo(out) }
            } ?: throw IllegalStateException("Couldn't write the download")
        } else {
            val dir = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                "SPACE",
            ).apply { mkdirs() }
            file.copyTo(File(dir, file.name), overwrite = true)
        }
        val name = file.name
        file.delete()
        return name
    }
}
